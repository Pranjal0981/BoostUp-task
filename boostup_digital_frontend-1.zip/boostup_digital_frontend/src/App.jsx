import { useState } from 'react'
import { Route, Routes } from 'react-router-dom'
import { Login, Profile, Register } from './components/Auth'
import { useSelector } from 'react-redux'
import { Unauthorized } from './components/Unauthorized'
import { NotFound } from './components/Notfound'

function App() {
  const {user,isAuth}=useSelector((state)=>state.user)
  const isUser=isAuth && user
  return (
    <>
    <Routes>
      <Route path='/' element={<Login/>}/>
      <Route path='/register' element={<Register/>}/>
      <Route path='/profile' element={isUser?<Profile/>:<Unauthorized/>}/>
      <Route path='*' element={<NotFound/>}/>
    </Routes>
    </>
  )
}

export default App
