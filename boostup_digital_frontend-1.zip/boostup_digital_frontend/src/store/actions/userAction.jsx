import { Modal, notification } from "antd";
import axios from "../../config/axios";
import { saveUser, removeUser } from "../reducers/userSlice";
const token=localStorage.getItem('token')||null
console.log(token)
export const asyncCurrentUser = (token) => async (dispatch, getState) => {
    try {
        const response = await axios.post('/user/currentInvestor', null, {
            headers: { Authorization: `Bearer ${token}` }
        });
        await dispatch(saveUser(response.data.user));
    } catch (error) {
        console.error(error);
    }
};


export const asyncUserRegister = (formData) => async (dispatch, getState) => {
    try {
       
        console.log(formData)
        const response = await axios.post('/user/register', formData, {
            headers: {
                'Content-Type': 'multipart/form-data', // Set content type to multipart/form-data
            }
        });

        // Handle success response
        if (response.data && response.data.message) {
            notification.success({
                message: 'Success',
                description: response.data.message,
                placement: 'topRight',
                duration: 3,
            });
        } else {
            notification.success({
                message: 'Success',
                description: 'Investor registered successfully',
                placement: 'topRight',
                duration: 3,
            });
        }
    } catch (error) {
        const errorMessage = error.response?.data?.message || 'Error in investor registration';

        notification.error({
            message: errorMessage,
            placement: 'topRight',
            duration: 3,
        });

        console.log(error);
    }
};


export const asyncUserLogin = (data, navigate) => async (dispatch, getState) => {
    try {
        const res = await axios.post('/user/login', data);
        console.log(res.data);
        await dispatch(asyncCurrentUser(res.data.token));
        const expiresInMilliseconds = res.data.expiresIn;
        const expirationTime = Date.now() + expiresInMilliseconds;
        localStorage.setItem('token', res.data.token);
        Modal.success({
            title: 'Login Successful',
            content: 'You have been logged in successfully.',
        });
        navigate('/profile')
    } catch (error) {
        Modal.error({
            title: 'Login Failed',
            content: 'Invalid username or password. Please try again.',
        });
    }
};


export const asyncSignOut=(navigate)=>async(dispacth,getState)=>{
    try {
        const response=await axios.get('/user/logout')
        dispacth(removeUser())
        notification.success({
            message: 'Success',
            description: response.data.message,
            placement: 'topRight',
            duration: 3,
        });
        navigate('/')
    } catch (error) {
        console.log(error)

    }
}
