import React from 'react';
import { Link } from 'react-router-dom';
import { Button, Result } from 'antd';

export const Unauthorized = () => {
    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
            <Result
                status="403"
                title="403"
                subTitle="Sorry, you are not authorized to access this page."
                extra={
                    <Link to="/">
                        <Button type="primary">Back to Home</Button>
                    </Link>
                }
            />
        </div>
    );
};
