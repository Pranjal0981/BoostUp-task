import React, { useEffect, useState } from 'react';
import { Form, Input, Button, Modal, Upload, Spin, Card } from 'antd';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { asyncSignOut, asyncUserLogin, asyncUserRegister } from '../store/actions/userAction';
import { BiUpload } from 'react-icons/bi';
export const Register = () => {
    const [loading, setLoading] = useState(false);
    const [file, setFile] = useState(null);
    const dispatch = useDispatch();
    const [image, setImage] = useState(null); // Use null instead of ''
    const [username,setUsername]=useState('')
    const [email,setEmail]=useState('')
    const [name,setName]=useState('')
    const [password,setPassword]=useState('')
    const [phone,setPhone]=useState('')

    const onFinish = async (event) => {
        event.preventDefault();
        setLoading(true);
        const formData=new FormData()
        formData.append('image',image)
        formData.append('username',username)
        formData.append('name',name)
        formData.append('email',email)
        formData.append('password',password)
        formData.append('phone',phone)
            await dispatch(asyncUserRegister(formData));
    
    };

    

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
            <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
                <h1 className="text-3xl font-bold mb-6 text-blue-600 text-center">Register</h1>
                <form onSubmit={onFinish} className="space-y-4">
                    <div>
                        <label htmlFor="username" className="block text-sm font-medium text-gray-700">Username</label>
                        <input type="text" id="username" value={username} onChange={(e) => setUsername(e.target.value)} className="form-input mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full border-gray-300 rounded-md" />

                    </div>
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                        <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} className="form-input mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full border-gray-300 rounded-md" />

                    </div>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                        <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} className="form-input mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full border-gray-300 rounded-md" />
                    </div>
                    <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone</label>
                        <input type="tel" id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} className="form-input mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full border-gray-300 rounded-md" />

                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
                        <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} className="form-input mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full border-gray-300 rounded-md" />

                    </div>
                    <div>
                        <label htmlFor="image" className="block text-sm font-medium text-gray-700">Image</label>
                        <input type="file" id="image" name='image' onChange={(e) => setImage(e.target.files[0])} className="form-input mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full border-gray-300 rounded-md" />
                    </div>
                    <div className="text-center">
                        <button
                            type="submit"
                            className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                            disabled={loading}
                        >
                            {loading ? 'Registering...' : 'Register'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};


export const Login = () => {
    const [loading, setLoading] = useState(false);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const onFinish = async (values) => {
        setLoading(true);
            await dispatch(asyncUserLogin(values,navigate))
      
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
            <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
                <h1 className="text-3xl font-bold mb-6 text-blue-600 text-center">Login</h1>
                <Form
                    layout="vertical"
                    onFinish={onFinish}
                    initialValues={{
                        username: '',
                        password: '',
                    }}
                >
                    <Form.Item
                        label="Username"
                        name="username"
                        rules={[{ required: true, message: 'Please enter your username' }]}
                    >
                        <Input placeholder="Enter your username" />
                    </Form.Item>
                    <Form.Item
                        label="Password"
                        name="password"
                        rules={[{ required: true, message: 'Please enter your password' }]}
                    >
                        <Input.Password placeholder="Enter your password" />
                    </Form.Item>
                    <div className="text-center">
                        <Button type="primary" htmlType="submit" loading={loading} className="w-full">
                            Login
                        </Button>
                    </div>
                </Form>
            </div>
        </div>
    );
};


export const Profile = () => {
    const [formLoading, setFormLoading] = useState(true);
    const [form] = Form.useForm();
    const { user } = useSelector((state) => state.user);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    useEffect(() => {
        if (user) {
            form.setFieldsValue(user);
            setFormLoading(false);
        } else {
            navigate('/'); 
        }
    }, [user, form, navigate]);

    const handleLogout = () => {
        dispatch(asyncSignOut(navigate)); // Action to clear user data
    };

    if (formLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-100">
                <Spin size="large" />
            </div>
        );
    }

  
    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
            <Card
                title="Profile"
                className="w-full max-w-md"
                cover={
                    user.image ? (
                        <img
                            src={user.image.url}
                            alt="Profile"
                            className="object-cover h-48 w-full"
                        />
                    ) : (
                        <div className="h-48 w-full bg-gray-200 flex items-center justify-center">
                            <span className="text-gray-500">No Image Available</span>
                        </div>
                    )
                }
            >
                <div className="text-center mb-4">
                    <p className="text-xl font-semibold">Username: <span className="font-normal">{user.username}</span></p>
                    <p className="text-xl font-semibold">Name: <span className="font-normal">{user.name}</span></p>
                    <p className="text-xl font-semibold">Email: <span className="font-normal">{user.email}</span></p>
                    <p className="text-xl font-semibold">Phone: <span className="font-normal">{user.phone}</span></p>
                </div>
                <div className="text-center mt-4">
                    <Button type="primary" onClick={handleLogout} className="w-full">
                        Logout
                    </Button>
                </div>
            </Card>
        </div>
    );
};