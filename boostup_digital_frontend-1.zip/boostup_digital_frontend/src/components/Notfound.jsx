import React from 'react';
import { Link } from 'react-router-dom';
import { Button, Result } from 'antd';

export const NotFound = () => {
    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
            <Result
                status="404"
                title="404"
                subTitle="Sorry, the page you visited does not exist."
                extra={
                    <Link to="/">
                        <Button type="primary">Back to Home</Button>
                    </Link>
                }
            />
        </div>
    );
};
