const express = require('express');
const router = express.Router();

const { register, login, currentUser, logout } = require('../controllers/indexController'); // Fixed import here
const { isAuthenticated } = require('../middlewares/auth');

router.post('/register', register);
router.post('/login', login);
router.post('/currentInvestor', isAuthenticated, currentUser);
router.get('/logout', logout); // Fixed the function name here

module.exports = router;
