const { catchAsyncErrors } = require('../middlewares/catchAsyncErrors');
const { sendToken } = require('../utils/sendToken');
const bcrypt = require('bcryptjs');
const ErrorHandler = require('../utils/ErrorHandler');
const imagekit = require('../utils/imagekit').initimagekit();
const User = require('../models/userModel');
const jwt = require('jsonwebtoken');

exports.register = catchAsyncErrors(async (req, res, next) => {
    const { username, name, email, phone, password } = req.body;
    console.log(req);

    if (!username || !name || !email || !password || !phone) {
        return res.status(400).json({ success: false, message: "All fields are required" });
    }

    const existingUser = await User.findOne({ $or: [{ username }, { email }] });
    if (existingUser) {
        return res.status(400).json({ success: false, message: "User already exists" });
    }

    const imageFiles = req.files;
    if (!imageFiles || !imageFiles.image) {
        return res.status(400).json({ success: false, message: 'No image provided' });
    }

    const { data } = imageFiles.image;
    const uniqueFileName = `${Date.now()}`;
    const { fileId, url } = await imagekit.upload({
        file: data,
        fileName: uniqueFileName,
        folder: '/boostup_digital_task'
    });

    const user = await User.create({
        username,
        name,
        email,
        phone,
        password,
        image: {
            fieldId: fileId,
            url
        }
    });

    res.status(201).json({ success: true, message: "User registered successfully", user });
});

exports.login = catchAsyncErrors(async (req, res, next) => {
    try {
        console.log(req.body);
        const { username, password } = req.body;

        const user = await User.findOne({ username });

        if (!user) {
            return res.status(404).json({ message: 'Investor not found' });
        }

        const isPasswordMatch = await bcrypt.compare(password, user.password);

        if (!isPasswordMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        sendToken(user, 200, res);
    } catch (error) {
        console.error('Error in loginInvestor controller:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

exports.currentUser = catchAsyncErrors(async (req, res, next) => {
    try {
        const userId = req.id;
        const user = await User.findById(userId).exec();
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        await user.save();
        res.json({ success: true, user });
    } catch (error) {
        console.error('Error fetching current admin:', error);
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

exports.logout = catchAsyncErrors(async (req, res, next) => {
    res.clearCookie("token");
    res.json({ message: "Successfully signed out" });
});
